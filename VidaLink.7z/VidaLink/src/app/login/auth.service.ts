import { Injectable } from '@angular/core';
import { Usuario } from '../objetos/usuario';
import { Router } from '@angular/router';
import { EventEmitter } from 'protractor';

@Injectable()
export class AuthService {

  private usuarioAutenticado: boolean = false;

  constructor(private router: Router) { }

  login( usuario: Usuario ){
    let result = new Promise((resolve, reject) => {
      if(usuario.nome == 'vidalink' && usuario.senha == 'vida2018') {
        resolve(this.usuarioAutenticado = true);
        this.router.navigate(['home']);        
      }
      else{
        reject(this.usuarioAutenticado = false);
      }
    });
    return result;
    
  }

  usuarioEstaAutenticado(){
    return this.usuarioAutenticado;
  }

}
