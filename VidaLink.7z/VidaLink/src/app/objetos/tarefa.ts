export class Tarefa {
    titulo: string = '';
    descricao: string = '';
    data: any = '';
}