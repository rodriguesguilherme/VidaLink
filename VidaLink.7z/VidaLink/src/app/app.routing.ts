import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/compiler/src/core';

import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { AuthGuard } from './guards/auth.guard';


const APP_ROUTE: Routes = [

    { path: '', component: LoginComponent },
    { 
        path: 'home', component: HomeComponent,
        canActivate: [AuthGuard]
     }

];

export const routing: ModuleWithProviders = RouterModule.forRoot(APP_ROUTE);