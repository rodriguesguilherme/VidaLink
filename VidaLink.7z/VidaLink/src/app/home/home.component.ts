import { Component, OnInit } from '@angular/core';
import { Tarefa } from '../objetos/tarefa';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  tituloModal: string;
  // private tarefas: Tarefa = new Tarefa();
  private arrayTarefas: any[] = [];
  msgErro: string;

  constructor( ) { }

  ngOnInit() {
  }

 

  fechar(){
    document.getElementById('modal-add').style.display = 'none';
    document.getElementById('modal-alterar').style.display = 'none';
  }

  adicionar(){
    this.tituloModal = "Adicionar Tarefa";
    document.getElementById('modal-add').style.display = 'block';
  }

  alterar(tarefa){
    this.tituloModal = "Alterar Tarefa";
    document.getElementById('modal-alterar').style.display = 'block';

    let titulo:any = document.getElementById('tituloAlt');
    let descricao: any = document.getElementById('descricaoAlt');
    let data: any = document.getElementById('dataAlt');

    titulo.value = tarefa.titulo;
    descricao.value = tarefa.descricao;
    data.value = tarefa.data;
  }
  
  salvarAdd(){
    let id: any = document.getElementById('idAdd');
    let titulo:any = document.getElementById('tituloAdd');
    let descricao: any = document.getElementById('descricaoAdd');
    let data: any = document.getElementById('dataAdd');
    let tarefas: any[] = [++id.value,titulo.value, descricao.value, data.value];
    if(titulo.value != '' && descricao.value != '' && data.value != ''){
      this.arrayTarefas.push(tarefas);
      this.msgErro = "";
      document.getElementById('modal-add').style.display = 'none';
      console.log(tarefas);
    }else {
      this.msgErro = "Verifique se todos os campos foram preenchidos";
      console.log(tarefas);
    }
    
  }

  salvarAlt(){
    let titulo:any = document.getElementById('tituloAlt');
    let descricao: any = document.getElementById('descricaoAlt');
    let data: any = document.getElementById('dataAlt');
    
  }

  

}
